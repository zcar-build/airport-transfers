<?php

class transfers_faq extends transfers_entity
{
    public function __construct( $entity ) {
		parent::__construct( $entity, 'faq' );	
    }

}